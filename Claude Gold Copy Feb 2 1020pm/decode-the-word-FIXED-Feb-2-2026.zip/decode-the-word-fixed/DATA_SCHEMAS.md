# Data Schemas

## words.js
Contains:
- definition
- sentence
- focus
- tags
- grade bands

No UI logic. No audio logic.

## phoneme_data.js
Contains:
- phoneme
- IPA
- mouth placement
- audio references

## translations.js
Meaning only. Never phonics.