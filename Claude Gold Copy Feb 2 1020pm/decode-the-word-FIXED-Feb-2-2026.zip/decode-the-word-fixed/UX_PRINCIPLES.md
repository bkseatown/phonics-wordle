# UX Principles

- Calm
- Predictable
- Visual
- Low text
- High contrast

Design for ASD / ADHD / EAL first.