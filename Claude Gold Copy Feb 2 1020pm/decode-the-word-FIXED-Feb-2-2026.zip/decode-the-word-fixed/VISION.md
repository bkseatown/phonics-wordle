# Ultimate Vision

Students think it is a game.
Teachers know it is instruction.
Families feel included in their own language.

This tool exists to remove barriers, not add features.