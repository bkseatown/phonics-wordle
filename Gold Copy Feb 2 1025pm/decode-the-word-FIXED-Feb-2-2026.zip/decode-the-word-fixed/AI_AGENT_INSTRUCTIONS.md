# Instructions for AI Agents

Do NOT simplify by deleting features.
Do NOT refactor without understanding pedagogy.
Do NOT assume English proficiency.

You are protecting learning, not code elegance.